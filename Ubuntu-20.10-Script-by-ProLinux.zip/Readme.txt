How to Install Chroot ?

1) copy script in internal storage (eg. /sdcard)
2) Download termux ,open and type su in termux
3) execute script (eg. sh install-20.10.sh )

Update : no need to execute fix-internet.sh